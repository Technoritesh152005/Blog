import React, { useCallback } from "react";
import { useForm } from "react-hook-form";
import { Button, Input, RTE, Select } from "..";
import appwriteService from "../../appwrite/config";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

// This defines a React component called PostForm.
// post is a prop:// If post exists → we are editing an existing post.
// If post is undefined → we are creating a new post.
export default function PostForm({ post }) {

    // useForm initializes the form and gives us helper functions:
// register: Connects inputs to the form state.
// handleSubmit: Handles form submission.
// watch: Watch specific fields for changes.
// setValue: Manually change a field value.

    const { register, handleSubmit, watch, setValue, control, getValues } = useForm({
        defaultValues: {
            title: post?.title || "",
            slug: post?.$id || "",
            content: post?.content || "",
            status: post?.status || "active",
        },
    });

    const navigate = useNavigate();
    const userData = useSelector((state) => state.auth.userData);

    // data → All form field values collected automatically by react-hook-form.
    const submit = async (data) => {
        // if post exists, we are updating an existing post.
        if (post) {
            // Upload the new image if provided, otherwise keep the existing one.
            const file = data.image[0] ? await appwriteService.uploadFile(data.image[0]) : null;

            // If a new file was uploaded and there was an existing featured image, delete the old one.
            if (file) {
                appwriteService.deleteFile(post.featuredImage);
            }
            // Update the post with new data and possibly new featured image.
            const dbPost = await appwriteService.updatePost(post.$id, {
                ...data,
                // Replace featuredImage with new file ID if uploaded.
                featuredImage: file ? file.$id : undefined,
            });

            // Navigate to the updated post's page.
            if (dbPost) {
                navigate(`/post/${dbPost.$id}`);
            }
        } 
        // If post does not exist, we are creating a new post.
        else {
            const file = await appwriteService.uploadFile(data.image[0]);
            
            // Only proceed if the file upload was successful.
            // 
            if (file) {
                const fileId = file.$id;
                // Save the uploaded image ID in form data.
                data.featuredImage = fileId;
                // Create a new post on backend with all data + userId.
                const dbPost = await appwriteService.createPost({ ...data, userId: userData.$id });

                if (dbPost) {
                    navigate(`/post/${dbPost.$id}`);
                }
            }
        }
    };

    const slugTransform = useCallback((value) => {
        if (value && typeof value === "string")
            return value
                .trim()
                .toLowerCase()
                .replace(/[^a-zA-Z\d\s]+/g, "-")
                .replace(/\s/g, "-");

        return "";
    }, []);

    React.useEffect(() => {
        const subscription = watch((value, { name }) => {
            if (name === "title") {
                setValue("slug", slugTransform(value.title), { shouldValidate: true });
            }
        });

        return () => subscription.unsubscribe();
    }, [watch, slugTransform, setValue]);

    return (
        <form onSubmit={handleSubmit(submit)} className="flex flex-wrap">
            <div className="w-2/3 px-2">
                <Input
                    label="Title :"
                    placeholder="Title"
                    className="mb-4"
                    {...register("title", { required: true })}
                />
                <Input
                    label="Slug :"
                    placeholder="Slug"
                    className="mb-4"
                    {...register("slug", { required: true })}
                    onInput={(e) => {
                        setValue("slug", slugTransform(e.currentTarget.value), { shouldValidate: true });
                    }}
                />
                <RTE label="Content :" name="content" control={control} defaultValue={getValues("content")} />
            </div>
            <div className="w-1/3 px-2">
                <Input
                    label="Featured Image :"
                    type="file"
                    className="mb-4"
                    accept="image/png, image/jpg, image/jpeg, image/gif"
                    {...register("image", { required: !post })}
                />
                {post && (
                    <div className="w-full mb-4">
                        <img
                            src={appwriteService.getFilePreview(post.featuredImage)}
                            alt={post.title}
                            className="rounded-lg"
                        />
                    </div>
                )}
                <Select
                    options={["active", "inactive"]}
                    label="Status"
                    className="mb-4"
                    {...register("status", { required: true })}
                />
                <Button type="submit" bgColor={post ? "bg-green-500" : undefined} className="w-full">
                    {post ? "Update" : "Submit"}
                </Button>
            </div>
        </form>
    );
}