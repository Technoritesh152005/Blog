import './App.css'
import Authservice from "./appwrite/Authservice"
import {useDispatch} from "react-redux"
import React,{useCallback,useEffect,useState} from "react"
import Header from './components/Header/Header';
import Footer from './components/Footer/Footer';

function App() {

  // "Initially, I don’t know whether user is logged in or not, I’m loading that info."
  const [loading,setLoading] =useState(true);
  const dispatch=useDispatch();

  // This runs when the app gets load

  useEffect(() => {

    // getUser is a promise
    // This is async and returns a promise.
  Authservice.getUser()
  // if user got means userdata will have
  // data is  value returned by Authservice.getUser().
  .then((data)=>{

    if(data){
     dispatch(login(data))
    }else{
      dispatch(logout())
    }
    
  })
  .catch((err)=>{

    dispatch(logout())
    alert("Some error occured while fetching user data"+err)
    
  })
  .finally(()=>{
    setLoading(false)
  })
  }, [])
  

  if (loading === true) {
    return (
      <div>
        <Header/>
        <h1>Fetching user data...</h1>
        <Footer/>
      </div>
    )
  } else {
    return (
      <div>
        <Header/>
        <h1>App Loaded ✅</h1>
        <Footer/>
      </div>
    )
  }
}

export default App
