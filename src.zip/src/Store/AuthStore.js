// here we are creating slice of authentication means small part of store to keep track of login nd logout

import {createSlice} from "@reduxjs/toolkit"

const initialStateAuth={
    status:false,
    userData:null

}

const AuthSlice=createSlice({
    name:"Auth",
    initialState:initialStateAuth,

    reducers:{
        login:(state,action)=>{
            // if anyone calls this function do this

            if(state.status===false && state.userData===null){
                state.status=true
                state.userData=action.payload
            }
        },

        logout:(state) =>{
            if(state.status===true && state.userData != null){
                state.status=false
                state.userData= null
            }
        }
    }
})

export default AuthSlice.reducer;

// these login nd logout r actions in reducers
export const {login,logout} = AuthSlice.actions


