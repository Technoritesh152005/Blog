import {Editor } from "@tinymce/tinymce-react"
import React from "react"
// Controller is a component from react-hook-form.
// Controller acts as a bridge to connect TinyMCE with react-hook-form.
import {Controller } from "react-hook-form"

function RTE({name,control,label,defaultValue=""}){
    return(
        <>
    <div>
         {label && <label className='inline-block mb-1 pl-1'>{label}</label>}

{/* name: The name of the field in your form.
control: The control object from react-hook-form that manages the form state. */}
{/* Without control, Controller won’t know how to connect this editor to the form. */}
         {/* <Controller> is used to wrap custom input components like TinyMCE. */}
         <Controller
         name={name}
         control={control}
         render={({field:{onChange}})=>
            (
                // The TinyMCE rich text editor component.
                <Editor
                // After initaialixing do these
                initialValue={defaultValue}
                init={
                    {
                        initialValue: defaultValue,
                height: 500,
                menubar: true,
                plugins: [
                "image",
                "advlist",
                "autolink",
                "lists",
                "link",
                "image",
                "charmap",
                "preview",
                "anchor",
                "searchreplace",
                "visualblocks",
                "code",
                "fullscreen",
                "insertdatetime",
                "media",
                "table",
                "code",
                "help",
                "wordcount",
                "anchor",
                ],
                 toolbar:
                "undo redo | blocks | image | bold italic forecolor | alignleft aligncenter bold italic forecolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent |removeformat | help",
                content_style: "body { font-family:Helvetica,Arial,sans-serif; font-size:14px }"
        
                    }
                }
                // onEditorChange={onChange} → Whenever the editor content changes, it calls onChange, which updates the form state in react-hook-form.
                onEditorChange={onChange}
                />
            )}
         />
    </div>
        </>
    )
}