import React  from "react";
import {Container} from "../index.js"
import {Link} from "react-router-dom"
import{useSelector} from "react-redux"
import {useNavigate} from "react-router-dom"
import Logout from "../index.js";

function Header(){
   
    //state=mean whole redux store
    // state.Auth = the slice you registered under key "Auth".
    // moreover we r checking the status of state in store
    // it takes whether status is active or not from authstore 
    const authStatus= useSelector((state)=>state.Auth.status)
    const navigate= useNavigate()

    const navItems=[
        {
            name:"Home",
            slug:"/",
            active:true
        },
        {
            name:"Login",
            slug:"/login",
            // only show login when authstatus in not 
            // means show if logout
            active:!authStatus
        }
        ,{
            name:"Sign-up",
            slug:"/Signup",
            active:!authStatus
        },{
            name:"All Post",
            slug:"/all-post",
            active:authStatus
        }
        ,{
            name:"Add Post",
            slug:"/add-post",
            active:authStatus
        }
    ]


    return (
        <>
        <header>
            <Container>
                <nav>
                    <div>
                        <ul>

                                {navItems.map((item)=>{
                                    item.active? (
                                        <li key={item.name}>
                                            <button
                                            onClick={()=>{
                                            // This directly goes to slug
                                            navigate(item.slug)
                                            }}
                                            >
                                           {item.name}
                                            </button>
                                        </li>
                                    ): null
                                })}

                                {/*Showing logout button if only the user authStatus is active   */}
                                if(authStatus){
                                    <Logout/>
                                }
                        </ul>
                    </div>
                </nav>
            </Container>
        </header>
        </>
    )
}

export default Header