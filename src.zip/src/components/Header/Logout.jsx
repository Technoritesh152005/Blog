import React from "react"
import Authservice from "../../appwrite/Authservice"
import {useDispatch} from "react-redux"
import {logout} from "../../redux/features/userSlice"

function Logout(){

    LogoutHandler=()=>{
        // logout is a promise session in Authservice.js
        Authservice.logout()
        .then(()=>{
            // make the store update
            dispatch(logout())
        })
        .catch((err)=>{
            alert("Some error occured while logging out"+err)
        })
    }
    return(
        <>
    <button
    className="btn btn-danger "
    onclick={LogoutHandler}
    >
        Logout
    </button>
        </>
    )
}

export default Logout