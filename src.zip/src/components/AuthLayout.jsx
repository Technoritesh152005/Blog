import React ,{useEffect,useState}from "react";
import { useNavigate } from "react-router-dom";
import {useSelector} from "react-redux"

// let authentication = true
export default function AuthLayoutProtected({children,authentication=true,}){


    const navigate=useNavigate()
    const [loader,setLoader] =useState("");
    // useSelector is a hook which is used to get the value from the store
    const authStatus = useSelector((state)=>state.auth.status)

    useEffect(()=>{

        // if(authStatus==="true"){
        //     navigate("/")
        // }else if(authStatus==="false"){
        //     navigate("/login")
        // }
        
        // true && false !== true
        // true && true
        
          if(authentication && authStatus !== authentication)
            {
            navigate("/login")
            }
            else if(!authentication && authStatus !== authentication)
            {
            navigate("/")
            }

        setLoader(false)

        // any change in this will run again.
        // it is necessary cause any change in the status must check the application
    },[authStatus,navigate,authentication])

    return loader? <h2>Loading ...</h2>: <> {children} </>

}