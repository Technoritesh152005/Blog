import React,{useState} from "react"
import {Link,useNavigate} from "react-router-dom"
import {login as StoreLogin} from "../store/authSlice"
import {useDispatch} from "react-redux"
import Input from "./Input.jsx"
import Button from "./Button.jsx"
import AuthService from "../appwrite/Authservice.js"
import {useForm} from "react-hook-form"

function Login(){

    const dispatch=useDispatch()
    const navigate=useNavigate()
    const {register,handleSubmit}=useForm()
    const [error,setError]=useState("")

    // login is a method which takes data and process the login algorithm.
    const login = async(data)=>{
    setError("")

    try{
        // when we give data for login we receive a session from it where it must be await
        const session = await AuthService.login(data)
        // if we got seession then we will get the user details
        // if not got session means some error occured or user not found

        if(session){
            const userDetails=await AuthService.getUser()
            // if we got user details then we will dispatch it to the store
            if(userDetails){
                dispatch(StoreLogin(userDetails))
                // after storing the details in store we will navigate to home page
                navigate("/")
            }
        }
        }
        catch(err){
        setError(err.message)
        }
    }
return (

  <div className="flex items-center justify-center w-full">
    <div className="mx-auto w-full max-w-lg bg-gray-100 rounded-xl p-10 border border-black/10">
     

      <h2 className="text-center text-2xl font-bold leading-tight">
        Sign in to your account
      </h2>

      <p className="mt-2 text-center text-base text-black/60">
        Don&apos;t have any account?&nbsp;
        <Link
          to="/signup"
          className="font-medium text-primary transition-all duration-200 hover:underline"
        >
          Sign Up
        </Link>
      </p>

    {/* Displaying the error You got  */}
      {error && <p className="text-red-600 mt-8 text-center">{error}</p>}

{/* Login form */}
      <form
    //   handleSubmit is a method or event in react hook form that gets trigger when the form is submitted and calls the login function
      onSubmit={handleSubmit(login)}
        className="mt-8 grid gap-6"
      >
        <div>
            {/* Exporting the input comment  for email input*/}
            <Input
            type="email"
            placeholder="Enter your email"
            label="Email"
            // here register is a method of react hook form that registers the input field into the form and it takes the name of the input field
            // "email" is the key of the input field and object need to be given for validation
            
            {...register("email",{
                required:true,
                validate: {
                    matchPattern:(value) => /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(value) || 
                    "Invalid email address"
                }
            })}

            />

            <Input
            label="Password"
            type="password"
            placeholder="Enter your password"
            // here register is a method of react hook form that registers the input field into the form and it takes the name of the input field
            // "password" is the key of the input field and object need to be given for validation
            
            {...register("password",{
                required:true,
                minLength:{value:6,message:"Password must be atleast 6 characters"}
            })}

            />
            
        </div>
      </form>

    </div>
  </div>
);

}
