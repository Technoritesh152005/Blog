import React from 'react'
import appwriteService from "../appwrite/config"
import {Link} from 'react-router-dom'

// this is the function which is used to diplay card and take the necessary things from database
// $id means it is the id of that particular post
function PostCard({$id, title, featuredImage}) {
    
  return (
    <Link to={`/post/${$id}`}>
        <div className='w-full bg-gray-100 rounded-xl p-4'>
            <div className='w-full justify-center mb-4'>
                {/* that file preview gives the id of file */}
                <img src={appwriteService.getFilePreview(featuredImage)} alt={title}
                className='rounded-xl' />

            </div>
            <h2
            className='text-xl font-bold'
            >{title}</h2>
        </div>
    </Link>
  )
}


export default PostCard