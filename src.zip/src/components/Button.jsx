import React from "react";

function Button(Btntext){
    // Btntext is provided cause
    Btntext,
    type="button",
    bgColor= "bg-blue-500"
    textColor="text-white"

    return(
        <>
        <button
        className={`px-4 py-2 ${bgColor},${textColor}`}
        >
            {Btntext}
        </button>
        </>
    )
}