// import { FaGithub, FaLinkedin } from "react-icons/fa";

// function Footer() {
//   return (
//     <footer className="bg-gray-900 text-gray-300 py-6 mt-10">
//       <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between px-4">
        
//         {/* Left - Brand */}
//         <div className="text-lg font-semibold tracking-wide">
//           © 2025 <span className="text-white">Ritesh.Ideas</span>
//         </div>

//         {/* Right - Social Icons */}
//         <div className="flex space-x-5 mt-4 md:mt-0">
//           <a 
//             href="https://github.com/your-github-username" 
//             target="_blank" 
//             rel="noopener noreferrer"
//             className="hover:text-white transition-colors"
//           >
//             <FaGithub size={24} />
//           </a>

//           <a 
//             href="https://linkedin.com/in/your-linkedin-username" 
//             target="_blank" 
//             rel="noopener noreferrer"
//             className="hover:text-white transition-colors"
//           >
//             <FaLinkedin size={24} />
//           </a>
//         </div>
//       </div>
//     </footer>
//   );
// }

// export default Footer;
