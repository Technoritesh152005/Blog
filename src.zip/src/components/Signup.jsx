import React, { useState } from 'react'
import AuthService from '../appwrite/auth'
import { Link, useNavigate } from 'react-router-dom'
import { login } from '../store/authSlice'
import Button from './Button.jsx'
import Input from './Input.jsx'
import { useDispatch } from 'react-redux'
import { useForm } from 'react-hook-form'

function Signup() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const [error, setError] = useState("")
  const { register, handleSubmit } = useForm()

  const signup = async (data) => {
    setError("")
    try {
      // it will create the account and return the session
      const data = await AuthService.createAccount(data)

      if (data) {
        // it will fetch userdetails from that account
        const userDetails = await AuthService.getUser()

        if (userDetails) {
          // set the details in store
          dispatch(login(userDetails))
          navigate("/")
        }
      }
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen w-full bg-gray-50 px-4">
      <div className="mx-auto w-full max-w-lg bg-white rounded-2xl shadow-md p-10 border border-gray-200">
        <h2 className="text-center text-2xl font-bold text-gray-900 leading-tight">
          Sign in to your account
        </h2>

        <p className="mt-2 text-center text-sm text-gray-600">
          Don&apos;t have any account?&nbsp;
          <Link
            to="/signup"
            className="font-medium text-indigo-600 transition-all duration-200 hover:underline"
          >
            Sign Up
          </Link>
        </p>

        {error && <p className="text-red-600 mt-6 text-center text-sm">{error}</p>}

        <form
          onSubmit={handleSubmit(signup)}
          className="mt-8 space-y-5"
        >
          {/* Input comp for Name */}
          <Input
            label="Name"
            placeholder="Enter your name"
            type="text"
            className="w-full rounded-lg border border-gray-300 p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            {...register("name", {
              required: true,
              minLength: 6
            })}
          />

          <Input
            type="email"
            placeholder="Enter your email"
            label="Email"
            className="w-full rounded-lg border border-gray-300 p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            {...register("email", {
              required: true,
              validate: {
                matchPattern: (value) =>
                  /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(value) ||
                  "Invalid email address"
              }
            })}
          />

          <Input
            type="password"
            label="Password"
            placeholder="Enter your password"
            className="w-full rounded-lg border border-gray-300 p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            {...register("password", {
              required: true,
            })}
          />

          <Button
            type="submit"
            className="w-full py-3 rounded-lg bg-indigo-600 text-white font-medium hover:bg-indigo-700 transition duration-200"
          >
            Create Account
          </Button>
        </form>
      </div>
    </div>
  )
}

export default Signup
