import React,{useId} from "react"

const SelectRef=React.forwardRef(function SelectField({
    // what all will have in select field will show here
    label,
    // it is a array only=>options
    options,
    className,
    ...props
},refernece){
    const Id=useId()

    return(
        <>
        <div className="">

        {label && <label htmlFor={Id} >

        <select
        id={Id}
        ref={refernece}
        className=""
        {...props}
        >
            if(options) {options.map((item)=> 
            <options key={options} value={options}>
                {options}
            </options>)}
            

        </select>

            </label>}
        </div>
        </>
    )

})


export default SelectRef