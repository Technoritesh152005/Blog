import React from "react";

function Container({child}){
    return(
        <>
        <div>
            <h1>
                Container {child}
            </h1>
        </div>
        </>
    )
}

export default Container