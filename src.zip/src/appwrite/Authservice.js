import {Client,Account,ID} from "appwrite"
import conf from "../config/conf";

// creating a class of authSrvice
// // A class is used when you want to group related data and functionality together.
// In your case:
// this.client = Appwrite client
// this.account = Appwrite account object
export class Authservice{
    // creating the client object
    // It is an object provided by Appwrite SDK that knows how to talk to your Appwrite backend (API
    client =new Client();
    account;

    // The constructor in a class is a special method that automatically runs when you create an object of that class using new.
    constructor(){
        this.client
        .setEndpoint(conf.appwriteURL)
        .setProject(conf.appwiteProjectId)

        // Here, you are creating an Account object from Appwrite SDK.
        this.account=new Account(this.client)
    }

    // to create account a promise is required which will take time and only proceed further when account is succesfully declared
    async createAccount ({email,password,name}){

        try{
        // creating the account by taking the parameters
        // Here, you are not creating a new Account object. Instead, you are using the already prepared this.account (from constructor) to call its API method .create(), which tells Appwrite server:
        const userAccount=await this.account.create(ID.unique(),email,password,name)

        if(userAccount){

            // call the login method
            return this.login({email,password})
        }else{
            return userAccount
        }

        }catch(err){

        }
    }

    async login({email,password}){
        
        try{
            const login=await this.account.createEmailSession(email,password)
            return login
        }
        catch(err){
            throw err
        }
}

    async getUser(){
        try{
            if(this.account){
                return await this.account.get()
            }
        }
        catch(err){
            return  null
        }
    }

    async logout(){
        try{
            return await this.account.deleteSessions("current")
        }catch(err){
            throw err
        }   
    }

     async sendEmailOtp(email) {
    try {
      const userId = ID.unique(); // temporary ID for OTP
      return await this.account.createEmailToken(userId, email);
    } catch (err) {
      throw err;
    }
  }

    async verifyEmailOtp(userId, secret) {
    try {
      return await this.account.createSession(userId, secret);
    } catch (err) {
      throw err;
    }
  }
}

// creating a object of it nd passing the object only to components

const authSeviceObj= new Authservice();

// exporting object only
export default authSeviceObj