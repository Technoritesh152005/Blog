import {Client,Account,ID,Databases,Storage,Query} from "appwrite"
import conf from "../config/conf";

export default class Databases{

    client=new Client();
    databases;
    storage;

    constructor(){
        this.client
        .setEndpoint(conf.appwriteURL)
        .setProject(conf.appwiteProjectId)
        this.databases=new Database(this.client)
        this.storage = new Storage(this.client)
    }

    async createPost({title,ID,status,content,featuredImage,userId}){
        // This function receives all the details of a blog post from your frontend (the blog form).

        try{
            // creating document in the database means creating a new blog post in database row
            return await this.databases.createDocument(
                conf.appwriteDatabaseId,
                //   the database you’re using
                conf.appwriteCollectionId,
                ID.unique(),// creates a unique ID for this document
                // content need to pass
                {
                    title,
                    content,
                    featuredImage,
                    status,
                    userId
                }
            )
        }catch(err){
            throw err
        }

    }

    async updatePost(documentID,{title,status,content,featuredImage}){

        try{
            return await this.databases.updateDocument(
                conf.appwriteDatabaseId,
                conf.appwriteCollectionId,
                documentID,
                // change the existing content list with the new content
                {
                    title,
                    content,
                    featuredImage,
                    status

                }
            )
        }catch(err){
            console.log(err)
        }
    }
    // While deleting the post we only require its database collection nd its document id
    async deletePost(documentID){

        try{
            await this.databases.deleteDocument(
                conf.appwriteDatabaseId,
                conf.appwriteCollectionId,
                documentID
            )
            alert("Deleted Succesfully")
        }catch(err){
            throw err
        }
    }

    async getSinglePost(documentID){

        try{

            return await this.databases.getDocument(
                conf.documentID,
                conf.appwriteDatabaseId,
                conf.appwriteCollectionId
            )
        }catch(err){
            throw err
        }
    }

    // in this we are getting all post from database and we send here query to database saying return all collection which status is eqaul to active blog elements
    // it is provided in array form cause we can give multiple queires also
    async getAllPosts(queries=[Query.equal("status","active")]){

        try{

            return await this.databases.listDocuments(
                conf.appwriteDatabaseId,
                conf.appwriteCollectionId,
                queries,

            )
        }catch(err){
            throw err
        }
    }

    async uploadFile(file){

        try{

            return await this.storage.createFile(
                conf.appwriteBucketId,
                ID.unique(),
                file,
            )

        }
        catch(err){
            throw err
        }
    }
    // we get id of the file during return 

    async deleteFile(fileId){

        try{

            await this.storage.deleteFile(
                conf.appwriteBucketId,
                fileId
            )

            return true
        }catch (err){
            throw err
            return false
        }
    }

    getFilePreview(fileId){
        return this.storage.getFilePreview(
            conf.appwriteBucketId,
            fileId
        )
    }
}
const Databaseobj=new Databases()